import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-teacher',
  templateUrl: './admin-teacher.component.html',
  styleUrl: './admin-teacher.component.css'
})
export class AdminTeacherComponent {

}
