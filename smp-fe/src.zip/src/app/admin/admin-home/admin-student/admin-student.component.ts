import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-student',
  templateUrl: './admin-student.component.html',
  styleUrl: './admin-student.component.css'
})
export class AdminStudentComponent {

}
