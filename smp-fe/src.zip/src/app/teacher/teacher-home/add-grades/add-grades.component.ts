import { Component } from '@angular/core';

@Component({
  selector: 'app-add-grades',
  templateUrl: './add-grades.component.html',
  styleUrl: './add-grades.component.css'
})
export class AddGradesComponent {

}
