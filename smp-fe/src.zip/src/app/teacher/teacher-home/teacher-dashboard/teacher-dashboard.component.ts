import { Component } from '@angular/core';
import { Notice } from '../../../models/notice.model';
import { NoticeService } from '../../../services/notice.service';

@Component({
  selector: 'app-teacher-dashboard',
  templateUrl: './teacher-dashboard.component.html',
  styleUrl: './teacher-dashboard.component.css'
})
export class TeacherDashboardComponent {

  notices: Notice[];

  constructor(private noticeService: NoticeService) {
    this.noticeService.getAllNotices().subscribe(notices => this.notices = notices);
   
  }
  isNoticeExpired(expiry_date:string):boolean {
    if(!expiry_date){
      return false;
    }
    const today=new Date();
    const expiry=new Date(expiry_date);
    return today>expiry;
  }

}
