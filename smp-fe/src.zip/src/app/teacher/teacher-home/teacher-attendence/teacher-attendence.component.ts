import { Component } from '@angular/core';

@Component({
  selector: 'app-teacher-attendence',
  templateUrl: './teacher-attendence.component.html',
  styleUrl: './teacher-attendence.component.css'
})
export class TeacherAttendenceComponent {

}
