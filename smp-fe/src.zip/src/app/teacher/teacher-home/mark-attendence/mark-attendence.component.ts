import { Component } from '@angular/core';

@Component({
  selector: 'app-mark-attendence',
  templateUrl: './mark-attendence.component.html',
  styleUrl: './mark-attendence.component.css'
})
export class MarkAttendenceComponent {

}
