export interface Notice {
    notice_id: number;
    title?: string;
    content?: string;
    publish_date?: string;
    expiry_date?: string;
}